# Backwards compatibility only

**Note!** As of v0.18, `tank_vendor.shotgun_authentication` has been to `sgtk.authentication`. 

Proxy methods have been left here to ensure backwards compatibility. For any authentication
related access, please use `sgtk.authentication`. The `tank_vendor.shotgun_authentication` package 
is no longer part of the  official Toolkit Core API and will be removed at some point in the future.
